package com.example.springapp.ClassExerciseDay4.exercise4.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.springapp.ClassExerciseDay4.exercise4.model.Patient;

@Repository
public interface PatientRepo extends JpaRepository<Patient,Integer>{
    
}

