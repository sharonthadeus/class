package com.example.springapp.ClassExerciseDay6.exercise2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springapp.ClassExerciseDay6.exercise2.model.Student;

public interface StudentRepo extends JpaRepository<Student,Integer>{
    
}
